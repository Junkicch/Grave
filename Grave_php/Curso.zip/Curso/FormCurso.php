<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Cadastro Curso</title>
        <link href="../img/Marca D'água Grave Preto.png" rel="icon">
        <link rel="stylesheet" href="../css/style.css"/>
        <!--<link rel="stylesheet" href="../css/formulariotop.css"/>-->
        <script>
            function limpa_formulário_cep() {
                //Limpa valores do formulário de cep.
                document.getElementById('endereco').value = ("");
                document.getElementById('bairro').value = ("");
                document.getElementById('cidade').value = ("");

            }

            function meu_callback(conteudo) {
                if (!("erro" in conteudo)) {
                    //Atualiza os campos com os valores.
                    document.getElementById('endereco').value = (conteudo.logradouro);
                    document.getElementById('bairro').value = (conteudo.bairro);
                    document.getElementById('cidade').value = (conteudo.localidade);

                } //end if.
                else {
                    //CEP não Encontrado.
                    limpa_formulário_cep();
                    alert("CEP não encontrado.");
                }
            }

            function pesquisacep(valor) {

                //Nova variável "cep" somente com dígitos.
                var cep = valor.replace(/\D/g, '');

                //Verifica se campo cep possui valor informado.
                if (cep != "") {

                    //Expressão regular para validar o CEP.
                    var validacep = /^[0-9]{8}$/;

                    //Valida o formato do CEP.
                    if (validacep.test(cep)) {

                        //Preenche os campos com "..." enquanto consulta webservice.
                        document.getElementById('endereco').value = "...";
                        document.getElementById('bairro').value = "...";
                        document.getElementById('cidade').value = "...";


                        //Cria um elemento javascript.
                        var script = document.createElement('script');

                        //Sincroniza com o callback.
                        script.src = 'https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback';

                        //Insere script no documento e carrega o conteúdo.
                        document.body.appendChild(script);

                    } //end if.
                    else {
                        //cep é inválido.
                        limpa_formulário_cep();
                        alert("Formato de CEP inválido.");
                    }
                } //end if.
                else {
                    //cep sem valor, limpa formulário.
                    limpa_formulário_cep();
                }
            }
            ;
        </script>
    </head>

    <body class="usuario">


        <header class="header" >
            <a href="indexmenu.html"><img src="../img/Grave Store Logo HD.png" alt="Imagem" title="logo" width="80" height="70"/></a>
            <nav class="menu">
                <ul>

                    <li><a href="#">Perfil</a>



                        <ul>
                            <li><a href="../Usuario/FormUsuario.php" class="labelInput">Cadastrar</a></li>
                            <li><a href="../Usuario/Consultarusuario.php">Consultar</a>
                        </ul>
                    </li>
                    <li><a href="#">Produtos</a>
                        <ul>
                            <li><a href="../Produto/FormProduto.php">Cadastrar</a></li>
                            <li><a href="../Produto/Consultarproduto.php">Consultar</a>
                        </ul>
                    </li>

                    <li><a href="#">Fornecedores</a>
                        <ul>
                            <li><a href="../Fornecedor/FormFornecedor.php">Cadastrar</a></li>
                            <li><a href="../Fornecedor/Consultarfornecedor.php">Consultar</a>
                        </ul>
                    </li>

                    <li><a href="#">Vendas</a>
                        <ul>
                            <li><a href="venda/FormVenda.php">Cadastrar</a></li>
                            <li><a href="venda/Consultarvenda.php">Consultar</a>
                        </ul>
                    </li>

                    <li><a href="#">Funcionarios</a>
                        <ul>
                            <li><a href="funcionario/FormFuncionario.php">Cadastrar</a></li>
                            <li><a href="funcionario/Consultarfuncionario.php">Consultar</a>
                        </ul>
                    </li>
                    <li><a href="Contato.html">Contato</a></li>
                </ul>
                <li>
                    <a href="#">Curso</a>
                    <ul>
                        <li><a href="FormCurso.php">Cadastrar</a></li>
                        <li><a href="Consultarcurso.php">Consultar</a>
                        </li>
            </nav>
        </header>

        <main class="main">



            <div class="produto">
                <h2>Cadastro Curso</h2>
                <form method="post" action="cadastrarcurso.php" class="formulario">

                    <table>
                        <ul class="form">
                            <label id="lbnome" class="labelInput">Local:</label>
                            <select id="iptestado" name="local" class="inputUser" value="<?= $campo["local"] ?>"/>
                            <option value="Selecione">Selecione</option>
                            <option value="Ceilândia(QNN 2)">Ceilândia(QNN 2)</option>
                            <option value="Ceilândia(QNN 3)">Ceilândia(QNN 3)</option>
                            </select>
                        </ul>
                        <ul class="form">
                            <label id="lbnome" class="labelInput">Previsão de Início:</label>
                            <select id="iptestado" name="prev_inicio" class="inputUser" value="<?= $campo["prev_inicio"] ?>"/>
                            <option value="Selecione">Selecione</option>
                            <option value="05/09/2022">05/09/2022</option>
                            <option value="03/10/2022">03/10/2022</option>
                            </select>
                        </ul>
                        <ul class="form">
                            <label id="lbnome" class="labelInput">Horário:</label>
                            <select id="iptestado" name="horario" class="inputUser" value="<?= $campo["horario"] ?>"/>
                            <option value="Selecione">Selecione</option>
                            <option value="8h ás 12h">8h ás 12h</option>
                            <option value="19h ás 22h">19h ás 22h</option>
                            </select>
                        </ul>       

                        <ul class="form">
                            <button type="submit" id="Cadastrar" class="hvr-fade ">Cadastrar</button>
                            <a href="../indexmenu.html"> <input type="button" id="Cancelar" class="hvr-fade " value="Cancelar"/></a>
                        </ul> 
                    </table>
                </form>

            </div>
            <img src="../img/Marca D'água Grave Preto.png" alt="Imagem" height="500" width="400" class="fundo">


        </main>
    </body>
</html>


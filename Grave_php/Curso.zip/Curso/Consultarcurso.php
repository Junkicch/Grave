<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Consultar Produto</title>
        <link type="text/css" rel="stylesheet" href="../css/style.css">
    
    </head>

     <body class="consulta">
         <header class="header">
            <a href="indexmenu.html"><img src="../img/Grave Store Logo HD.png" alt="Imagem" title="logo" width="80" height="70"/></a>
        <nav class="menu">
           
            <ul>
                
                <li><a href="#">Perfil</a>
                    <ul>
                        <li><a href="../Usuario/FormUsuario.php">Cadastrar</a></li>
                        <li><a href="../Usuario/Consultarusuario.php">Consultar</a>
                    </ul>
                </li>
                <li><a href="#">Produtos</a>
                    <ul>
                        <li><a href="FormCurso.php">Cadastrar</a></li>
                        <li><a href="Consultarcurso.php">Consultar</a>
                    </ul>
                </li>

                <li><a href="#">Fornecedores</a>
                <ul>
                    <li><a href="../Fornecedor/FormFornecedor.php">Cadastrar</a></li>
                    <li><a href="../Fornecedor/Consultarfornecedor.php">Consultar</a>
                    </ul>
                </li>
                
                <li><a href="#">Vendas</a>
                <ul>
                    <li><a href="venda/FormVenda.php">Cadastrar</a></li>
                    <li><a href="venda/Consultarvenda.php">Consultar</a>
                    </ul>
                </li>
                
                <li><a href="#">Funcionarios</a>
                <ul>
                    <li><a href="funcionario/FormFuncionario.php">Cadastrar</a></li>
                    <li><a href="funcionario/Consultarfuncionario.php">Consultar</a>
                    </ul>
                </li>
                <li><a href="Contato.html">Contato</a></li>
            </ul>
            <li><a href="#">Curso</a>
                    <ul>
                        <li><a href="FormCurso.php">Cadastrar</a></li>
                        <li><a href="cadastrarcurso.php">Consultar</a></li>
                        </li>
                    </ul>
        </nav>
        </header>
         <main>
                <h1>Consultar Curso Cadastrado</h1>
                <table>
                    <tr class="id">
                        <td align="center"> <strong>ID</strong></td>
                        <td align="center"> <strong>Local</strong></td>
                        <td align="center"> <strong>Previsão de Início</strong></td>	
                        <td align="center"> <strong>Horário</strong></td>	
                        <td width="10"> <strong>Editar</strong></td>
                        <td width="10"> <strong>Deletar</strong></td>
                    </tr>

                    <?php
                        include("../conectarbd.php");
                        $selecionar= mysqli_query($conn, "SELECT * FROM tb_curso");
                        while ($campo= mysqli_fetch_array($selecionar)){?>
                            <tr class="usuarios">
                                <td align="center"><?=$campo["id_curso"]?></td>
                                <td align="center"><?=$campo["local"]?></td>
                                <td align="center"><?=$campo["prev_inicio"]?></td>
                                <td align="center"><?=$campo["horario"]?></td>
                                <td align="center"><a href="FormEditarCurso.php?editarid=<?php echo $campo ['id_curso'];?>" class="editar">Editar</a></td>
                                <td align="center"><a href="ExcluirCurso.php?p=excluir&curso=<?php echo $campo['id_curso'];?>" class="editar">Excluir</a></td>
                            </tr>
                    <?php }?>
                </table><br>
                <a href="../indexmenu.html"><input type="button" class="hvr-fade" value="Cancelar"/></a>
         </main>
    </body>
</html>

<?php

include("../conectarbd.php");

$recid= filter_input(INPUT_POST, 'id');

$reclocal= filter_input(INPUT_POST, 'local');

$recprev_inicio= filter_input(INPUT_POST, 'prev_inicio');

$rechorario= filter_input(INPUT_POST, 'horario');

  if(mysqli_query($conn, "UPDATE tb_curso SET local='$reclocal', prev_inicio='$recprev_inicio', horario='$rechorario' WHERE id_curso='$recid'")) {

    echo "<script>alert('Dados alterado com sucesso!'); window.location = 'Consultarcurso.php';</script>";

  }else {

    echo "Não foi possível alterar os dados no Banco de Dados" . $recid . "<br>" . mysqli_error($conn);

  }

  mysqli_close($conn);



?>